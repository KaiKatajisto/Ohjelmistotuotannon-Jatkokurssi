[Tehtäväpohja täältä](https://web-palvelinohjelmointi-21.mooc.fi/osa-2/3-tietokantojen-kasittely)

Vaatii JDK 11 tai vanhemman

Käyntiin (ja uusiksi buildaus tarvittaessa):
docker compose up --build

Sammutus:
docker compose down

lisätty test.yml workflow, kokeillaan mvn testin ajoa